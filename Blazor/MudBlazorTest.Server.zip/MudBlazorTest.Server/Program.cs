using Microsoft.AspNetCore.Hosting.StaticWebAssets;
using MudBlazorTest.Server.Startup;

var builder = WebApplication.CreateBuilder(args);

StaticWebAssetsLoader.UseStaticWebAssets(builder.Environment,builder.Configuration);

builder.Services.RegisterServices();

// Add services to the container.

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
	app
		.UseExceptionHandler("/Error")
		.UseHsts();
	// The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
}

app
	.UseHttpsRedirection()
	.UseStaticFiles()
	.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();